(function () {
  'use strict';

  // Ano do rodapé
  var ano = document.getElementById('ano');
  if (ano) ano.textContent = new Date().getFullYear();

  // Filtro por categoria: botões com data-filtro, cartões com data-categoria
  var botoes = document.querySelectorAll('[data-filtro]');
  var cartoes = document.querySelectorAll('[data-categoria]');
  botoes.forEach(function (botao) {
    botao.addEventListener('click', function () {
      var filtro = botao.getAttribute('data-filtro');
      botoes.forEach(function (b) { b.setAttribute('aria-pressed', b === botao ? 'true' : 'false'); });
      cartoes.forEach(function (c) {
        c.hidden = filtro !== 'todas' && c.getAttribute('data-categoria') !== filtro;
      });
    });
  });

  // Lightbox: qualquer <img data-lightbox> amplia ao clicar
  var caixa = null;
  function fechar() { if (caixa) { caixa.remove(); caixa = null; } }
  document.querySelectorAll('img[data-lightbox]').forEach(function (img) {
    img.style.cursor = 'zoom-in';
    img.addEventListener('click', function () {
      caixa = document.createElement('div');
      caixa.className = 'lightbox';
      caixa.setAttribute('role', 'dialog');
      caixa.setAttribute('aria-label', 'Imagem ampliada. Clique ou pressione Esc para fechar.');
      var grande = document.createElement('img');
      grande.src = img.currentSrc || img.src;
      grande.alt = img.alt;
      caixa.appendChild(grande);
      caixa.addEventListener('click', fechar);
      document.body.appendChild(caixa);
    });
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') fechar(); });
})();
